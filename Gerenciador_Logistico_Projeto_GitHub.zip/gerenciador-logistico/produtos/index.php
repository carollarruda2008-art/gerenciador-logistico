<?php
require_once __DIR__ . '/../includes/bootstrap.php';
$pageTitle = 'Produtos'; $current = 'produtos';
$rows = db()->query('SELECT * FROM produtos ORDER BY nome')->fetchAll();
require __DIR__ . '/../includes/header.php';
?>
<div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-3"><div><h1 class="h3 mb-1">Produtos</h1><p class="text-secondary mb-0">Cadastre e mantenha os produtos disponíveis para os fretes.</p></div><a class="btn btn-primary" href="<?= e(url('produtos/cadastrar.php')) ?>">+ Novo produto</a></div>
<div class="card shadow-sm"><div class="table-responsive"><table class="table table-hover align-middle mb-0"><thead><tr><th>Código</th><th>Produto</th><th>Peso (kg)</th><th>Quantidade</th><th>Valor</th><th class="text-end">Ações</th></tr></thead><tbody>
<?php if (!$rows): ?><tr><td colspan="6" class="text-center text-secondary py-4">Nenhum produto cadastrado.</td></tr><?php else: foreach($rows as $row): ?>
<tr><td><?= e($row['codigo']) ?></td><td><strong><?= e($row['nome']) ?></strong><div class="small text-secondary"><?= e($row['descricao']) ?></div></td><td><?= e($row['peso']) ?></td><td><?= (int)$row['quantidade'] ?></td><td><?= e(money($row['valor'])) ?></td><td class="text-end text-nowrap"><a class="btn btn-sm btn-outline-primary" href="<?= e(url('produtos/editar.php?id='.$row['id'])) ?>">Editar</a> <form class="d-inline" method="post" action="<?= e(url('produtos/excluir.php')) ?>" data-confirm="Excluir este produto? Se estiver relacionado a um frete, a exclusão será bloqueada."><?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$row['id'] ?>"><button class="btn btn-sm btn-outline-danger">Excluir</button></form></td></tr>
<?php endforeach; endif; ?></tbody></table></div></div>
<?php require __DIR__ . '/../includes/footer.php'; ?>
