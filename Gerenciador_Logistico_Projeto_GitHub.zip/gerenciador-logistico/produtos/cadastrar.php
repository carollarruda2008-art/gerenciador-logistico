<?php
require_once __DIR__ . '/../includes/bootstrap.php';
$pageTitle='Cadastrar produto'; $current='produtos';
$errors=[]; $data=['codigo'=>'','nome'=>'','descricao'=>'','peso'=>'','quantidade'=>'0','valor'=>''];
if ($_SERVER['REQUEST_METHOD']==='POST') {
    verify_csrf();
    foreach ($data as $key=>$v) $data[$key]=trim((string)($_POST[$key] ?? $v));
    if ($data['codigo']==='') $errors[]='Informe o código do produto.';
    if ($data['nome']==='') $errors[]='Informe o nome do produto.';
    if (!is_numeric($data['peso']) || (float)$data['peso']<0) $errors[]='Informe um peso válido.';
    if (filter_var($data['quantidade'], FILTER_VALIDATE_INT)===false || (int)$data['quantidade']<0) $errors[]='Informe uma quantidade inteira igual ou maior que zero.';
    if (!is_numeric($data['valor']) || (float)$data['valor']<0) $errors[]='Informe um valor válido.';
    if (!$errors) {
        try {
            $stmt=db()->prepare('INSERT INTO produtos (codigo,nome,descricao,peso,quantidade,valor) VALUES (?,?,?,?,?,?)');
            $stmt->execute([$data['codigo'],$data['nome'],$data['descricao'] ?: null,$data['peso'],$data['quantidade'],$data['valor']]);
            flash('success','Produto cadastrado com sucesso.'); redirect('produtos/index.php');
        } catch (PDOException $ex) { $errors[]=$ex->getCode()==='23000'?'Já existe um produto com esse código.':'Não foi possível salvar o produto.'; }
    }
}
require __DIR__ . '/../includes/header.php';
?>
<div class="mb-3"><a href="<?= e(url('produtos/index.php')) ?>" class="text-decoration-none">← Voltar para produtos</a></div><h1 class="h3">Cadastrar produto</h1>
<?php if($errors): ?><div class="alert alert-danger"><ul class="mb-0"><?php foreach($errors as $error): ?><li><?= e($error) ?></li><?php endforeach; ?></ul></div><?php endif; ?>
<form method="post" class="card card-body shadow-sm form-card"><?= csrf_field() ?>
<div class="row g-3"><div class="col-md-4"><label class="form-label">Código *</label><input name="codigo" class="form-control" maxlength="40" required value="<?= e($data['codigo']) ?>"></div><div class="col-md-8"><label class="form-label">Nome do produto *</label><input name="nome" class="form-control" maxlength="150" required value="<?= e($data['nome']) ?>"></div><div class="col-12"><label class="form-label">Descrição</label><textarea name="descricao" class="form-control" rows="2"><?= e($data['descricao']) ?></textarea></div><div class="col-md-4"><label class="form-label">Peso (kg) *</label><input type="number" min="0" step="0.001" name="peso" class="form-control" required value="<?= e($data['peso']) ?>"></div><div class="col-md-4"><label class="form-label">Quantidade *</label><input type="number" min="0" step="1" name="quantidade" class="form-control" required value="<?= e($data['quantidade']) ?>"></div><div class="col-md-4"><label class="form-label">Valor (R$) *</label><input type="number" min="0" step="0.01" name="valor" class="form-control" required value="<?= e($data['valor']) ?>"></div></div>
<div class="mt-4 d-flex gap-2"><button class="btn btn-primary">Salvar produto</button><a class="btn btn-outline-secondary" href="<?= e(url('produtos/index.php')) ?>">Cancelar</a></div></form>
<?php require __DIR__ . '/../includes/footer.php'; ?>
