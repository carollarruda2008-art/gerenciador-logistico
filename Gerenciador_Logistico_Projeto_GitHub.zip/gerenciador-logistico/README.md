# Gerenciador Logístico

Projeto acadêmico desenvolvido para a disciplina **Fundamentos de Programação para Internet**.

**Aluna:** Caroline V S Arruda  
**Curso:** Engenharia de Software  
**Polo:** Toledo - PR

 A aplicação permite cadastrar produtos, endereços e transportadores, gerar fretes relacionando um transportador a vários produtos e consultar/exportar um relatório de fretes por dia.

## Tecnologias

- PHP 8 ou superior
- MySQL/MariaDB
- HTML5, CSS3 e JavaScript
- Bootstrap 5.3
- PDO para acesso ao banco de dados
- XAMPP para ambiente local

## Funcionalidades implementadas

- Painel inicial com totais e fretes recentes.
- Cadastro, listagem, edição e exclusão de produtos.
- Cadastro, listagem, edição e exclusão de endereços, classificados como origem, destino ou ambos.
- Cadastro, listagem, edição e exclusão de transportadores.
- Geração de fretes com um transportador, endereço de origem, endereço de destino e vários produtos.
- Consulta detalhada de cada frete.
- Relatório filtrado por data, com exportação CSV.
- Consultas preparadas com PDO, escape da saída HTML e token CSRF nos formulários POST.

## Como executar no XAMPP

1. Instale e abra o XAMPP.
2. Inicie os serviços **Apache** e **MySQL**.
3. Copie a pasta `gerenciador-logistico` para o diretório `C:\xampp\htdocs\` (Windows). No Linux, utilize o diretório `htdocs` da instalação do XAMPP.
4. Abra `http://localhost/phpmyadmin`.
5. Importe o arquivo `database.sql` na aba **Importar**. O script cria o banco `gerenciador_logistico` e as cinco tabelas necessárias.
6. (Opcional) Para facilitar os testes, importe também `database_dados_exemplo.sql`, que cria produtos, endereços e transportadores fictícios. Não use esses dados como informações reais.
7. Confira os dados de conexão em `config/config.php`. A configuração inicial considera o usuário `root` do MySQL sem senha, padrão comum em instalações locais do XAMPP. Altere `DB_USER` e `DB_PASS` quando necessário.
8. Confira `BASE_URL` em `config/config.php`. Se o nome da pasta continuar `gerenciador-logistico`, mantenha `/gerenciador-logistico`.
9. Acesse `http://localhost/gerenciador-logistico/`.

## Primeiros passos dentro do sistema

1. Cadastre alguns produtos.
2. Cadastre pelo menos um endereço do tipo **origem** (ou **ambos**).
3. Cadastre pelo menos um endereço do tipo **destino** (ou **ambos**).
4. Cadastre um transportador.
5. Entre em **Fretes**, escolha o transportador, origem, destino e data, e adicione um ou mais produtos.
6. Consulte o frete gerado e teste o relatório para a data escolhida.

## Estrutura de pastas

```text
gerenciador-logistico/
├── assets/                 # CSS e JavaScript
├── config/                 # Configuração e conexão PDO
├── enderecos/              # CRUD de endereços
├── fretes/                 # Geração, listagem e detalhes de fretes
├── includes/               # Funções compartilhadas e layout
├── produtos/               # CRUD de produtos
├── relatorios/             # Consulta e exportação CSV
├── transportadores/        # CRUD de transportadores
├── database.sql            # Criação do banco e das tabelas
├── index.php               # Painel inicial
└── README.md
```

## Relacionamentos do banco

- Um transportador pode aparecer em vários fretes.
- Cada frete possui um endereço de origem e um endereço de destino.
- A tabela `frete_produtos` faz a relação entre fretes e produtos, permitindo vários produtos no mesmo frete e que um produto apareça em fretes diferentes.

## Versionamento com Git

Execute os comandos na pasta do projeto. Faça commits pequenos sempre que concluir uma funcionalidade ou alteração relevante:

```bash
git init
git add .
git commit -m "Estrutura inicial do projeto"
```

Depois de implementar ou revisar cada módulo, registre as mudanças:

```bash
git add .
git commit -m "Implementa cadastro de produtos"
git add .
git commit -m "Implementa cadastro de enderecos"
git add .
git commit -m "Implementa cadastro de transportadores"
git add .
git commit -m "Implementa geracao e consulta de fretes"
git add .
git commit -m "Implementa relatorio diario de fretes"
```

Crie um repositório **público** no GitHub e conecte-o ao projeto:

```bash
git branch -M main
git remote add origin https://github.com/SEU-USUARIO/gerenciador-logistico.git
git push -u origin main
```

Substitua `SEU-USUARIO` pelo seu usuário do GitHub.

## Situação de validação

Todos os arquivos PHP foram submetidos à verificação de sintaxe no ambiente de preparação. A conexão com o MySQL/MariaDB, o funcionamento dos formulários e a exportação CSV ainda precisam ser testados localmente no XAMPP. Consulte `documentacao/PLANO_TESTES.md` e não marque esses testes como concluídos antes de executá-los.

## Observações para a apresentação

- O sistema é uma versão acadêmica inicial, sem autenticação de usuários.
- O Bootstrap é carregado por CDN; para carregar o visual completo, o navegador precisa de conexão com a internet.
- CPF/CNPJ e CEP são armazenados como dados informados no formulário; não há validação de autenticidade ou consulta a serviços externos.
- O total exibido nos detalhes do frete é uma soma informativa do valor cadastrado dos produtos, não representa cálculo de tarifa ou preço de transporte.

## Documentação para a entrega

- `documentacao/Etapa_1_Analise_Gerenciador_Logistico.pdf`: esboços das telas da Etapa 1.
- `documentacao/GUIA_XAMPP_E_EXECUCAO.md`: instalação e execução no Windows com XAMPP.
- `documentacao/ROTEIRO_VIDEO.md`: roteiro de apoio para o vídeo de 5 a 10 minutos.
- `documentacao/CHECKLIST_ENTREGA.md`: lista de conferência das três etapas.
- `documentacao/PUBLICAR_GITHUB_WINDOWS.md`: instruções para publicar o repositório público.
- `documentacao/PLANO_TESTES.md`: casos que precisam ser executados no XAMPP.
- `documentacao/PONTOS_A_CONFIRMAR_COM_TUTOR.md`: observação sobre um requisito ambíguo da APO.
- `database_dados_exemplo.sql`: dados fictícios opcionais para facilitar a demonstração.
