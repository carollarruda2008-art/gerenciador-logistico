<?php
require_once __DIR__ . '/../includes/bootstrap.php'; $pageTitle='Endereços'; $current='enderecos';
$rows=db()->query('SELECT * FROM enderecos ORDER BY cidade,rua')->fetchAll();
require __DIR__.'/../includes/header.php';
?>
<div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-3"><div><h1 class="h3 mb-1">Endereços</h1><p class="text-secondary mb-0">Gerencie locais de origem e destino dos fretes.</p></div><a class="btn btn-primary" href="<?=e(url('enderecos/cadastrar.php'))?>">+ Novo endereço</a></div>
<div class="card shadow-sm"><div class="table-responsive"><table class="table table-hover align-middle mb-0"><thead><tr><th>Tipo</th><th>Endereço</th><th>CEP</th><th>Cidade/UF</th><th class="text-end">Ações</th></tr></thead><tbody>
<?php if(!$rows):?><tr><td colspan="5" class="text-center text-secondary py-4">Nenhum endereço cadastrado.</td></tr><?php else:foreach($rows as $r):?><tr><td><span class="badge text-bg-light"><?=e(ucfirst($r['tipo']))?></span></td><td><?=e($r['rua'])?>, <?=e($r['numero'])?> <div class="small text-secondary"><?=e($r['bairro'])?><?= $r['complemento']?' · '.e($r['complemento']):'' ?></div></td><td><?=e($r['cep'])?></td><td><?=e($r['cidade'])?>/<?=e($r['estado'])?></td><td class="text-end text-nowrap"><a class="btn btn-sm btn-outline-primary" href="<?=e(url('enderecos/editar.php?id='.$r['id']))?>">Editar</a> <form class="d-inline" method="post" action="<?=e(url('enderecos/excluir.php'))?>" data-confirm="Excluir este endereço? A exclusão é bloqueada se estiver em um frete."><?=csrf_field()?><input type="hidden" name="id" value="<?=(int)$r['id']?>"><button class="btn btn-sm btn-outline-danger">Excluir</button></form></td></tr><?php endforeach;endif;?>
</tbody></table></div></div>
<?php require __DIR__.'/../includes/footer.php'; ?>
