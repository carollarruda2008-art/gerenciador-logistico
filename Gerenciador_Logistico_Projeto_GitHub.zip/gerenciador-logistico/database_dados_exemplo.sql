-- Dados fictícios para demonstração acadêmica.
-- Importe este arquivo SOMENTE depois de importar database.sql.
-- Os registros usam códigos/documentos exclusivos para evitar colisões.
USE gerenciador_logistico;

INSERT INTO produtos (codigo, nome, descricao, peso, quantidade, valor) VALUES
('DEMO-P001', 'Caixa de papel A4', 'Caixa com resmas de papel para escritório.', 12.500, 20, 189.90),
('DEMO-P002', 'Monitor 24 polegadas', 'Monitor LED para estação de trabalho.', 4.200, 8, 799.00),
('DEMO-P003', 'Cadeira de escritório', 'Cadeira ergonômica com regulagem de altura.', 11.000, 5, 649.50);

INSERT INTO enderecos (tipo, cep, rua, numero, bairro, cidade, estado, complemento) VALUES
('origem', '80010-000', 'Rua Exemplo', '100', 'Centro', 'Curitiba', 'PR', 'Depósito de demonstração'),
('destino', '01001-000', 'Avenida Modelo', '250', 'Sé', 'São Paulo', 'SP', 'Recebimento de demonstração'),
('ambos', '13010-000', 'Rua das Flores', '45', 'Centro', 'Campinas', 'SP', 'Endereço de demonstração');

INSERT INTO transportadores (nome, tipo_documento, documento, telefone, tipo_veiculo, placa_veiculo) VALUES
('Transportadora Exemplo Ltda.', 'CNPJ', '00.000.000/0001-91', '(45) 99999-0001', 'Caminhão baú', 'ABC1D23'),
('João da Silva - Transportes', 'CPF', '000.000.000-00', '(45) 99999-0002', 'Van', 'DEF4G56');
