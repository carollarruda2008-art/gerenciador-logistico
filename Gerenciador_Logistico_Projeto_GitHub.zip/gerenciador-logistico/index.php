<?php
require_once __DIR__ . '/includes/bootstrap.php';
$pageTitle = 'Painel inicial';
$current = 'inicio';
$totals = [
    'produtos' => (int)db()->query('SELECT COUNT(*) FROM produtos')->fetchColumn(),
    'enderecos' => (int)db()->query('SELECT COUNT(*) FROM enderecos')->fetchColumn(),
    'transportadores' => (int)db()->query('SELECT COUNT(*) FROM transportadores')->fetchColumn(),
    'fretes' => (int)db()->query('SELECT COUNT(*) FROM fretes')->fetchColumn(),
];
$recent = db()->query("SELECT f.id, f.codigo, f.data_frete, t.nome AS transportador, ao.cidade AS origem, ad.cidade AS destino,
    (SELECT COUNT(*) FROM frete_produtos fp WHERE fp.frete_id=f.id) AS total_produtos
    FROM fretes f JOIN transportadores t ON t.id=f.transportador_id
    JOIN enderecos ao ON ao.id=f.origem_id JOIN enderecos ad ON ad.id=f.destino_id
    ORDER BY f.id DESC LIMIT 5")->fetchAll();
require __DIR__ . '/includes/header.php';
?>
<div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-4">
    <div><h1 class="h3 mb-1">Painel inicial</h1><p class="text-secondary mb-0">Visão geral das informações logísticas cadastradas.</p></div>
    <a class="btn btn-primary" href="<?= e(url('fretes/cadastrar.php')) ?>">+ Gerar novo frete</a>
</div>
<div class="row g-3 mb-4">
    <?php foreach ([['Produtos',$totals['produtos'],'produtos/index.php'],['Endereços',$totals['enderecos'],'enderecos/index.php'],['Transportadores',$totals['transportadores'],'transportadores/index.php'],['Fretes',$totals['fretes'],'fretes/index.php']] as [$label,$value,$link]): ?>
    <div class="col-6 col-xl-3"><a class="text-decoration-none" href="<?= e(url($link)) ?>"><div class="card metric-card h-100"><div class="card-body"><div class="text-secondary small"><?= e($label) ?></div><div class="display-6 fw-semibold text-dark"><?= (int)$value ?></div><span class="small text-primary">Acessar cadastro →</span></div></div></a></div>
    <?php endforeach; ?>
</div>
<div class="card shadow-sm">
    <div class="card-header bg-white d-flex justify-content-between align-items-center"><h2 class="h5 mb-0">Fretes recentes</h2><a href="<?= e(url('fretes/index.php')) ?>" class="small">Ver todos</a></div>
    <div class="table-responsive"><table class="table table-hover align-middle mb-0"><thead><tr><th>Código</th><th>Data</th><th>Transportador</th><th>Origem</th><th>Destino</th><th>Produtos</th></tr></thead><tbody>
    <?php if (!$recent): ?><tr><td colspan="6" class="text-center text-secondary py-4">Ainda não há fretes cadastrados.</td></tr><?php else: foreach ($recent as $row): ?>
    <tr><td><a href="<?= e(url('fretes/visualizar.php?id=' . $row['id'])) ?>"><?= e($row['codigo']) ?></a></td><td><?= e(date_br($row['data_frete'])) ?></td><td><?= e($row['transportador']) ?></td><td><?= e($row['origem']) ?></td><td><?= e($row['destino']) ?></td><td><?= (int)$row['total_produtos'] ?></td></tr>
    <?php endforeach; endif; ?>
    </tbody></table></div>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>
